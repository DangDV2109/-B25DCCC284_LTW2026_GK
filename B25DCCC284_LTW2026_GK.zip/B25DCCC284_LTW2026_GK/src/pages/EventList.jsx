import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const AddEvent = ({ events, onAdd }) => {
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [date, setDate] = useState('');
  const [capacity, setCapacity] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!name.trim() || !location.trim() || !date || !capacity) {
      setErrorMsg('Vui lòng nhập đầy đủ thông tin phía dưới form');
      return;
    }

    const capNum = Number(capacity);
    if (!Number.isInteger(capNum) || capNum < 10 || capNum > 1000) {
      setErrorMsg('Sức chứa phải từ 10 đến 1000');
      return;
    }

    const maxId = events.length > 0 ? Math.max(...events.map(ev => Number(ev.id))) : 0;

    const newEvent = {
      id: maxId + 1,
      name: name.trim(),
      location: location.trim(),
      date,
      capacity: capNum,
      registered: 0
    };

    onAdd(newEvent);
    navigate('/events', { replace: true });
  };

  return (
    <div>
      <h2>Thêm mới</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="name-input">Tên sự kiện</label>
          <br />
          <input
            id="name-input"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>

        <div style={{ marginTop: '10px' }}>
          <label htmlFor="location-input">Địa điểm</label>
          <br />
          <input
            id="location-input"
            type="text"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
          />
        </div>

        <div style={{ marginTop: '10px' }}>
          <label htmlFor="date-input">Ngày diễn ra</label>
          <br />
          <input
            id="date-input"
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
        </div>

        <div style={{ marginTop: '10px' }}>
          <label htmlFor="capacity-input">Sức chứa</label>
          <br />
          <input
            id="capacity-input"
            type="number"
            value={capacity}
            onChange={(e) => setCapacity(e.target.value)}
          />
        </div>

        {errorMsg && <div className="error-msg">{errorMsg}</div>}
        <button type="submit" style={{ marginTop: '15px' }}>Thêm</button>
      </form>
    </div>
  );
};

export default AddEvent;