const Home = ({ events }) => {
    const totalEvents = events.length;
    const totalRegistered = events.reduce((acc, curr) => acc + curr.registered, 0);
    const totalFull = events.reduce((acc, curr) => (curr.registered >= curr.capacity ? acc + 1 : acc), 0);

    return (
        <div>
            <h1>Sự kiện CLB</h1>
            <p>Tổng số sự kiện: {totalEvents}</p>
            <p>Tổng số lượt đăng ký: {totalRegistered}</p>
            <p>Số sự kiện đã đầy: {totalFull}</p>
        </div>
    );
};

export default Home;
